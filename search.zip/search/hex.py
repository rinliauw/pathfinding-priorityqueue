class Hex:
	
	q = 0	#the row coordinate
	r = 0	#the column coordinate

	def 